-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2020 at 04:56 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kelvin`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `uid` varchar(6) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(6) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  `dept` varchar(50) DEFAULT NULL,
  `mobile` bigint(10) DEFAULT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`uid`, `name`, `email`, `gender`, `designation`, `dept`, `mobile`, `photo`) VALUES
('1', 'SANAL KUMAR', 'sanalkumar.vr.aeu@kct.ac.in', 'Male', 'PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, 'sanalkumar.jpg'),
('10', 'RAJ KUMAR', 'rajkumar.g.aeu@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, 'rajkumar.jpg'),
('100', 'NIRMAL KUMAR', 'nirmalkumar.a@kct.ac.in', 'Male', 'PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('101', 'UDHAYASHANKAR', 'haiudhaya@rediffmail.com', 'Male', 'ASSOCIATE PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('102', 'PREMALATHA', 'kppremalatha@gmail.com', 'Female', 'ASSOCIATE PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('103', 'KAVITHA', 'kavithain2@yahoo.com', 'Female', 'ASSOCIATE PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('104', 'MOHANRAJ', 'mmrguru@rediffmail.com', 'Male', 'ASSOCIATE PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('105', 'KARUNAMOORTHY', 'karunamoorthy.b.eee@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('106', 'PRAKASH', 'prakashnarayanasamy@yahoo.com', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('107', 'NIRMALA', 'm.nirmala.gct@gmail.com', 'Female', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('108', 'SHANTHI', 'shanthits@gmail.com', 'Female', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, 'shanthi.jpg'),
('109', 'RAMPRABU', 'jrameee@gmail.com', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, 'jrameee.jpg'),
('11', 'VIJAYANANDH', 'vijayanandh.r.aeu@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('110', 'KALIAPPAN', 'kalies.me@gmail.com', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('111', 'SURESHKUMAR', 'sureshpls45@yahoo.co.in', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('112', 'SANDHYA DEVI', 'sandhyars2003@yahoo.co.in', 'Female', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('113', 'ANUSHREE', 'anushree.g.eee@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('114', 'SHARMITHA', 'sharmitha.d.eee@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('115', 'BALAJI', 'balaji.vr.eee@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('116', 'VISWANATHAN', 'viswanathan.t.eee@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('117', 'DINESHKUMAR', 'dinesh161190@gmail.com', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('118', 'MOHANA SUNDARAM', 'mohanasundaram.n.eee@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('119', 'ARUNKUMAR', 'arunkumar.s.eee@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('12', 'MUTHU KUMAR', 'muthukumar.s.aero@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('120', 'SASI KUMAR', 'sasikumar.c.eee@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('121', 'SURYAPRAKASH', 'suryaprakash.s.eee@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('122', 'VINOTH KUMAR', 'vinothkumar.n.eee@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('123', 'PARAMASIVAM', 'paramasivam.k.ece@kct.ac.in', 'Male', 'PROFESSOR', 'EMBEDDED SYSTEMS TECHNOLOGIES', 1234567891, ''),
('124', 'KANDASAMY', 'bickandha@gmail.com', 'Male', 'ASSOCIATE PROFESSOR', 'EMBEDDED SYSTEMS TECHNOLOGIES', 1234567891, ''),
('125', 'MATHAN KUMAR', 'mathankumar.m.eee@kct.ac.in', 'Male', 'ASST PROFESSOR', 'EMBEDDED SYSTEMS TECHNOLOGIES', 1234567891, ''),
('126', 'THIRUMOORTHI', 'thirumoorthi.p.eee@kct.ac.in', 'Male', 'PROFESSOR', 'POWER ELECTRONICS AND DRIVES', 1234567891, ''),
('127', 'MAITHILI', 'maitheerainbow@gmail.com', 'Female', 'ASST PROFESSOR', 'POWER ELECTRONICS AND DRIVES', 1234567891, ''),
('128', 'GOVINDARAJU', 'govindaraju.s.ece@kct.ac.in', 'Male', 'PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('129', 'EZHILARASI', 'hod.eie@kct.ac.in', 'Female', 'PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('13', 'KIRUTHIKA', 'kiruthika.s.kciri@kct.ac.in', 'Female', 'ASST PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('130', 'ANILKUMAR', 'anilkumar.kk.eie@kct.ac.in', 'Male', 'PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('131', 'MAYURAPPRIYAN', 'mayurappriyan.ps.eie@kct.ac.in', 'Male', 'PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('132', 'DINESHKUMAR', 'dineshkumar.v.eie@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('133', 'UMESH', 'umesh.mv.eie@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('134', 'JEYADAISY', 'jeyadaisy.i.eie@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('135', 'ATHAPPAN', 'athappan.v.eie@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('136', 'MUTHURAMALINGAM', 'muthuramalingam.e.eie@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('137', 'MANIMEKALAI', 'manimekalai.v.eie@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('138', 'SARAVANABALAJI', 'saravanabalaji.m.eie@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('139', 'SARAVANAKUMAR', 'saravanakumar.s.eie@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('14', 'BALAJI', 'balaji.k.kciri@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('140', 'RANGANATHAN', 'ranganathan.s.eie@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS & INSTRUMENTATION ENGINEERING', 1234567891, ''),
('141', 'RAMPRAKASH', 'ramprakash.k.ece@kct.ac.in', 'Male', 'PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('142', 'RAMALATHA', 'ramalatha.m.it@kct.ac.in', 'Female', 'PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('143', 'PASUPATHY', 'pasupathy.sa.mce@kct.ac.in', 'Male', 'PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('144', 'KAVITHA', 'kavitha.k.ece@kct.ac.in', 'Female', 'PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('145', 'AMSAVENI', 'amsaveni.a.ece@kct.ac.in', 'Female', 'PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('146', 'SHANTHI', 'shanthi.m.ece@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('147', 'HEMALATHA', 'hemakct@yahoo.com', 'Female', 'ASSOCIATE PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('148', 'UMAMAHESWARI', 'umarajaslm@sifymail.com', 'Female', 'ASSOCIATE PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('149', 'SASIKALA', 'sasikala.s.ece@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('15', 'SIVAKUMAR', 'sivakumar.s.auto@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('150', 'SHIVAPPRIYA', 'shivappriya.sn.ece@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('151', 'DARWIN', 'darwinr@ymail.com', 'Male', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('152', 'KARTHIKEYAN', 'karthikeyan.r.ece@kct.ac.inmail.com', 'Male', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('153', 'DHIVYA PRABA', 'rdhivyaktp@gmail.com', 'Female', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('154', 'KALAISELVI', 'kalaiselvi.a.ece@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('155', 'JASMINE', 'jasminejenil@gmail.com', 'Female', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('156', 'UMA MAHESWARI', 'umakce16@gmail.com', 'Female', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('157', 'ANUSHA', 'anusha.k.ece@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('158', 'KARTHIK', 'karthik.s.ece@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('159', 'KRITHIKA', 'krisan80@gmail.com', 'Female', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('16', 'THENMOZHI', 'thenmozhi.g.auto@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('160', 'ALLIN JOE', 'alinjoe.d.ece@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('161', 'KARTHI KUMAR', 'karthikumar.r.ece@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('162', 'CHANDRU', 'chandruece89@gmail.com', 'Male', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('163', 'SHIJI', 'shijishajahan@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('164', 'NAVANEETHAKRISHNAN', 'navaneethakrishnan.ece@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('165', 'KARTHIKA', 'karthika.k.ece@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('166', 'DAVID', 'david.s.ece@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('167', 'JASPAR VINITHA SUNDARI', 'jasparvinithasundari.t.ece@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('168', 'ARUN KUMAR', 'arunkumar.s.ece@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('169', 'ASHWINI A', 'ashwini.a.ece@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('17', 'KARTHIK', 'karthik.t.auto@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('170', 'TIMOTHY DHAYAKAR', 'timothy.ece@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('171', 'AJAY', 'ajay.vp.ece@kct.ac.in', 'Male', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('172', 'TAMILELAKKIYA', 'tamilelakkiya.s.ece@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 1234567891, ''),
('173', 'BHARATHI', 'bharathi.m.ece@kct.ac.in', 'Female', 'PROFESSOR', 'COMMUNICATION SYSTEMS', 1234567891, ''),
('174', 'ALAGUMEENAAKSHI', 'alagu_meenakshi@rediffmail.com', 'Female', 'ASSOCIATE PROFESSOR', 'COMMUNICATION SYSTEMS', 1234567891, ''),
('175', 'THILAGAVATHI', 'thilagavathi.k.ece@kct.ac.in', 'Female', 'ASST PROFESSOR', 'COMMUNICATION SYSTEMS', 1234567891, ''),
('176', 'RANI', 'ranithottungal@yahoo.com', 'Female', 'PROFESSOR', 'APPLIED ELECTRONICS', 1234567891, ''),
('177', 'NAGARATHINAM', 'rathina2k@yahoo.com', 'Female', 'ASST PROFESSOR', 'APPLIED ELECTRONICS', 1234567891, ''),
('178', 'BHAARATHI', 'bhaarathi_dhurai@yahoo.com', 'Female', 'PROFESSOR', 'FASHION TECHNOLOGY', 1234567891, ''),
('179', 'RAJ KUMAR', 'rraajj80@gmail.com', 'Male', 'ASSOCIATE PROFESSOR', 'FASHION TECHNOLOGY', 1234567891, ''),
('18', 'ANDREW PON ABRAHAM', 'andrew.auto@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('180', 'KRISHNAVENI', 'krishnassstyle@gmail.com', 'Female', 'ASSOCIATE PROFESSOR', 'FASHION TECHNOLOGY', 1234567891, ''),
('181', 'SHANTHI', 'radhakrishnanshanthi@yahoo.co.in', 'Female', 'ASSOCIATE PROFESSOR', 'FASHION TECHNOLOGY', 1234567891, ''),
('182', 'CHANDRA KUMAR', 'elitechandru@yahoo.com', 'Male', 'ASST PROFESSOR', 'FASHION TECHNOLOGY', 1234567891, ''),
('183', 'KAVITHA', 's_kavishna@yahoo.co.in', 'Female', 'ASST PROFESSOR', 'FASHION TECHNOLOGY', 1234567891, ''),
('184', 'ARUNRAJ', '2arunraj@gmail.com', 'Male', 'ASST PROFESSOR', 'FASHION TECHNOLOGY', 1234567891, ''),
('185', 'PRABU', 'prabukrishnaa@yahoo.com', 'Male', 'ASST PROFESSOR', 'FASHION TECHNOLOGY', 1234567891, ''),
('186', 'VARADARAJU', 'rvraju23@yahoo.co.in', 'Male', 'ASST PROFESSOR', 'FASHION TECHNOLOGY', 1234567891, ''),
('187', 'RAMAKRISHNAN', 'g.ramki15@gmail.com', 'Male', 'PROFESSOR', 'APPAREL TECHNOLOGY', 1234567891, ''),
('188', 'SENTTHIL KUMAR', 'cssentthil@gmail.com', 'Male', 'ASSOCIATE PROFESSOR', 'APPAREL TECHNOLOGY', 1234567891, ''),
('189', 'THAMBIDURAI', 'athambidurai@yahoo.com', 'Male', 'ASST PROFESSOR', 'APPAREL TECHNOLOGY', 1234567891, ''),
('19', 'SAIGANESH', 'saiganesh.j.auto@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('190', 'VANITHA', 'vanitha.v.cse@kct.ac.in', 'Female', 'PROFESSOR', 'INFORMATION TECHNOLOGY', 1234567891, ''),
('191', 'VIJILESH', 'vijilesh.v.it@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'INFORMATION TECHNOLOGY', 1234567891, ''),
('192', 'NANDAKUMAR', 'nandakumar.gs.cse@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'INFORMATION TECHNOLOGY', 1234567891, ''),
('193', 'ALAMELU', 'alamelu.m.it@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'INFORMATION TECHNOLOGY', 1234567891, ''),
('194', 'SHENBAGAM', 'shenbagam.p.it@kct.ac.in', 'Female', 'ASST PROFESSOR', 'INFORMATION TECHNOLOGY', 1234567891, ''),
('195', 'KANAGARAJ', 'kanagaraj.s.it@kct.ac.in', 'Male', 'ASST PROFESSOR', 'INFORMATION TECHNOLOGY', 1234567891, ''),
('196', 'PREMA AROKIA MARY', 'premaarokiamary.g.it@kct.ac.in', 'Female', 'ASST PROFESSOR', 'INFORMATION TECHNOLOGY', 1234567891, ''),
('197', 'SURESH', 'suresh.a.it@kct.ac.in', 'Male', 'ASST PROFESSOR', 'INFORMATION TECHNOLOGY', 1234567891, ''),
('198', 'HARI PRASATH', 'hariprasath.l.it@kct.ac.in', 'Male', 'ASST PROFESSOR', 'INFORMATION TECHNOLOGY', 1234567891, ''),
('199', 'SAROJA', 'saroja.mn.it@kct.ac.in', 'Female', 'ASST PROFESSOR', 'INFORMATION TECHNOLOGY', 1234567891, ''),
('2', 'SUNDARARAJ', 'sundararaj.k.aeu@kct.ac.in', 'Male', 'PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('20', 'SATISH', 'satish.s.auto@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('200', 'RAJATHI', 'rajathi.n.it@kct.ac.in', 'Female', 'PROFESSOR', 'DATA SCIENCES', 1234567891, ''),
('2001', 'sandy', '', NULL, NULL, NULL, NULL, ''),
('2005', '', '', NULL, NULL, NULL, 2147483647, ''),
('2006', '', '', NULL, NULL, NULL, 8870151621, ''),
('201', 'KAVITHA', 'kavitha.s.it@kct.ac.in', 'Female', 'ASST PROFESSOR', 'DATA SCIENCES', 1234567891, ''),
('202', 'NEDUNCHEZHIAN', 'vrn@kctbs.ac.in', 'Male', 'PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('203', 'MARY', 'marycherian@kctbs.ac.in', 'Female', 'PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('204', 'SWAMINATHAN', 'swaminathan@kctbs.ac.in', 'Male', 'PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('205', 'KANNAN', 'kannan@kctbs.ac.in', 'Male', 'PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('206', 'SANGEETHA', 'sangisubramanian@gmail.com', 'Female', 'ASSOCIATE PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('207', 'KAARTHIKHEYAN', 'profvkk@kctbs.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('208', 'KIRUPA PRIYADARSINI', 'kirupa@kctbs.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('209', 'VINAYAGASUNDARAM', 'rvs@kctbs.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('21', 'KISHORE', 'kishore.r.auto@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('210', 'JAISANKAR', 'jaisankar@kctbs.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('211', 'SENTHAMARAIKANNAN', 'placement@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('212', 'DEEPA', 'deepa@kctbs.ac.in', 'Female', 'ASST PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('213', 'POONGODI', 'poongodi@kctbs.ac.in', 'Female', 'ASST PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('214', 'LATHA', 'lathakamalesh@kctbs.ac.in', 'Female', 'ASST PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('215', 'MOHANAMANI', 'mohanamani@kctbs.ac.in', 'Female', 'ASST PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('216', 'NALINI', 'nalini@kctbs.ac.in', 'Female', 'ASST PROFESSOR', 'MASTERS IN BUSINESS ADMINISTRATION', 1234567891, ''),
('217', 'GEETHA', 'geethasuresh@rediffmail.com', 'Female', 'PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('218', 'MANIKANTAN', 'mani_dpm@yahoo.com', 'Male', 'ASSOCIATE PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('219', 'VIJAY PRAKASH', 'jv_prakash@rediffmail.com', 'Male', 'ASSOCIATE PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('22', 'RAJKUMAR', 'rajkumar.auto@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('220', 'HAMEED IBRAHIM', 'ibuhum@rediffmail.com', 'Male', 'ASST PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('221', 'KAVITHA', 'rk_kavitha@ymail.com', 'Female', 'ASST PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('222', 'PARAMESWARI', 'p_param@rediffmail.com', 'Female', 'ASST PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('223', 'RAJAN KRUPA', 'shyamkrupa@gmail.com', 'Male', 'ASST PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('224', 'JAYAKANTHAN', 'haijai2@gmail.com', 'Male', 'ASST PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('225', 'GEETHA', 'mcsgeetha@gmail.com', 'Female', 'ASST PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('226', 'JALAJA JAYALAKSHMI', 'vjalaja79@yahoo.com', 'Female', 'ASST PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('227', 'AMALA JAYANTHI', 'amalawithcontact@gmail.com', 'Female', 'ASST PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('228', 'DHANABAL', 'dhanabal.l.mca@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('229', 'RAMACHANDRAN', 'chandrurgp@gmail.com', 'Male', 'ASST PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('23', 'NAVEEN KUMAR', 'naveenkumar.c.auto@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('230', 'JAISINGH', 'jaisinghw@gmail.com', 'Male', 'ASST PROFESSOR', 'MASTERS IN COMPUTER APPLICATIONS', 1234567891, ''),
('231', 'VELMURUGAN', 'velmurugan.c.mec@kct.ac.in', 'Male', 'PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('232', 'MUTHUKUMARAN', 'muthukumaran.v.mec@kct.ac.in', 'Male', 'PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('233', 'MANIVEL', 'manivel.r.mec@kct.ac.in', 'Male', 'PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('234', 'MURUGANANTHAM', 'muruganantham.vr.mec@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('235', 'THIRUMURUGAVEERAKUMAR', 'thirumurugaveerakumar.s.mec@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('236', 'BALAJI', 'balaji.m.mec@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('237', 'SENTHILKUMAR', 'senthilkumar.b.mec@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('238', 'SANGEETHA', 'sangeetha.n.mec@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('239', 'SENTHILKUMAR', 'senthilkumar.km.mec@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('24', 'PRABHAKARAN', 'prabhakaran.a.auto@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('240', 'BALASUBRAMANIAN', 'balasubramanian.s.mec@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('241', 'ARUN', 'arun.kk.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('242', 'SIVAKUMAR', 'sivakumar.s.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('243', 'AYYAPPAN', 'ayyappan.pr.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('244', 'ARUN', 'arun.ap.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('245', 'MANIVEL MURALIDARAN', 'manivelmuralidaran.v.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('246', 'ULAGANATHAN', 'ulaganathan.k.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('247', 'BALAJI', 'balaji.s.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('248', 'PRABHU', 'prabhu.s.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('249', 'KRISHNAMOORTHI', 'krishnamoorthi.k.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('25', 'ARUN', 'arun.b.auto@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('250', 'RAMESH KUMAR', 'rameshkumar.m.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('251', 'RAJESH', 'rajesh.s.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('252', 'MOHAN KUMAR', 'mohankumar.rs.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('253', 'NAVANEETH', 'navaneeth.vr.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('254', 'SAMUEL RATNA KUMAR', 'samuelratnakumar.ps.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('255', 'PRABHU', 'prabhusubramaniam.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('256', 'LAKSHMANAN', 'lakshmanan.ks@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('257', 'JEEVA', 'jeeva.b.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('258', 'SUBBIAH', 'subbiah.s.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('259', 'PRADEEP', 'pradeep.p.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('26', 'MOHANKUMAR', 'mohankumar.s.auto@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('260', 'KARTHI', 'karthi.p.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('261', 'DEVAN', 'devan.pd.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('262', 'PRASHANTH', 'prashanth.p.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('263', 'KARUPPUSAMY', 'karuppusamy.t.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('264', 'SIVAKUMAR', 'sivakumar.siddhan.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('265', 'SURESH', 'suresh.s.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('266', 'VINAYAGAMOORTH', 'vinayagamoorthi.ma.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('267', 'RAMANATHAN', 'ramanathan.s.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('268', 'SREEHARAN', 'sreeharan.b.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('269', 'ANANTH', 'ananth.kr@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('27', 'VASANTHARAJ', 'vasantharaj.c@kct.ac.inm', 'Male', 'PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('270', 'KIRANLAL', 'kiranlal.s@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHANICAL ENGINEERING', 1234567891, ''),
('271', 'SATHYABALAN', 'sathyabalan.p.mec@kct.ac.in', 'Male', 'PROFESSOR', 'INDUSTRIAL ENGINEERING', 1234567891, ''),
('272', 'SUKUMAR', 'sukumar.tr.mec@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'INDUSTRIAL ENGINEERING', 1234567891, ''),
('273', 'MANIKANDA PRASATH', 'manikandaprasath.k.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'INDUSTRIAL ENGINEERING', 1234567891, ''),
('274', 'BHASKAR', 'bhaskar.s.mec@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'COMPUTER AIDED DESIGN AND MANUFACTURE', 1234567891, ''),
('275', 'THIRUMALAIMUTHUKUMARAN', 'thirumalaimuthukumaran.m.mec@kct.ac.in', 'Male', 'ASST PROFESSOR', 'COMPUTER AIDED DESIGN AND MANUFACTURE', 1234567891, ''),
('276', 'VASUKI', 'vasuki.a.ece@kct.ac.in', 'Female', 'PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('277', 'VENKATESAN', 'venkatesan.r.mce@kct.ac.in', 'Male', 'PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('278', 'AKILA', 'akila.k.mce@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('279', 'SARAVANA MOHAN', 'saravanamohan.m.mce@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('28', 'JOHN ALEXIS', 'johnalexis.s.auto@kct.ac.in', 'Male', 'PROFESSOR', 'AUTOMOBILE ENGINEERING', 1234567891, ''),
('280', 'SABITHA', 'sabitha.b.mce@kct.ac.in', 'Female', 'ASST PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('281', 'RAMKUMAR', 'ramkumar.a.mce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('282', 'SURESH', 'suresh.t.mce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('283', 'RAFFIK', 'raffikkmrs@gmail.com', 'Male', 'ASST PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('284', 'SARAVANAN', 'saravanan.r.mce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('285', 'MAGUDAPATHI', 'magudapathi.p.mce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('286', 'ANUSH', 'anush.p.mce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('287', 'MURUGESAN', 'ack.murugan@gmail.com', 'Male', 'ASST PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('288', 'SIVAGURU', 'sivaguru.j.mce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'MECHATRONICS ENGINEERING', 1234567891, ''),
('289', 'DHINAKARAN', 'mdhinakaran2000@yahoo.com', 'Male', 'ASSOCIATE PROFESSOR', 'TEXTILE TECHNOLOGY', 1234567891, ''),
('29', 'SARASWATHY', 'saraswathy.n.bt@kct.ac.in', 'Female', 'PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('290', 'RAMESH BABU', 'salemramesh@yahoo.com', 'Male', 'ASSOCIATE PROFESSOR', 'TEXTILE TECHNOLOGY', 1234567891, ''),
('291', 'CHANDRASEKARAN', 'chans_sekar@yahoo.co.in', 'Male', 'ASST PROFESSOR', 'TEXTILE TECHNOLOGY', 1234567891, ''),
('292', 'NATARAJAN', 'natarajanex@gmail.com', 'Male', 'ASST PROFESSOR', 'TEXTILE TECHNOLOGY', 1234567891, ''),
('293', 'SIVAKUMAR', 'sivasivaa123@rediffmail.com', 'Male', 'ASST PROFESSOR', 'TEXTILE TECHNOLOGY', 1234567891, ''),
('294', 'ARIHARASUDHAN', 'ariharasudhan@gmail.com', 'Male', 'ASST PROFESSOR', 'TEXTILE TECHNOLOGY', 1234567891, ''),
('295', 'SARAVANAN', 'saravanan.m.txt@kct.ac.in', 'Male', 'ASST PROFESSOR', 'TEXTILE TECHNOLOGY', 1234567891, ''),
('296', 'SUKANYADEVI', 'ssukanyas@rediffmail.com', 'Female', 'ASST PROFESSOR', 'TEXTILE TECHNOLOGY', 1234567891, ''),
('297', 'SRINIVASAN', 'srinivasan.j.ft@kct.ac.in', 'Male', 'PROFESSOR', 'TEXTILE TECHNOLOGY', 1234567891, ''),
('298', 'THANGAMANI', 'ktmanithanga@yahoo.co.in', 'Male', 'PROFESSOR', 'MASTERS OF TECHNOLOGY MANAGEMENT', 1234567891, ''),
('299', 'SUNDARESAN', 'shobsundar@yahoo.com', 'Male', 'ASSOCIATE PROFESSOR', 'MASTERS OF TECHNOLOGY MANAGEMENT', 1234567891, ''),
('3', 'PREMKUMAR', 'premkumar.ps.aeu@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('30', 'SHANMUGAPRAKASH', 'shanmugaprakash.m.bt@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('300', 'THANGESWARAN', 'thangeswaran_pt@yahoo.com', 'Male', 'ASST PROFESSOR', 'MASTERS OF TECHNOLOGY MANAGEMENT', 1234567891, ''),
('301', 'SANTHA', 'santha_jsk@yahoo.co.in', 'Female', 'ASSOCIATE PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('302', 'SHOBA', 'ussche@gmail.com', 'Female', 'ASSOCIATE PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('303', 'MARUDHACHALAM', 'marudhu14@gmail.com', 'Male', 'ASSOCIATE PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('304', 'MAYILDURAI', 'mayildurai@redifmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('305', 'SIVAHARI', 'sivaharir@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('306', 'SENGODAN', 'sengodan78@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('307', 'BALAMURUGAN', 'kctbala@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('308', 'SIVASAKTHI', 'ss_sakthimaths@yahoo.co.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('309', 'SELVANAYAKI', 'selva_sanju@yahoo.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('31', 'VINOHAR STEPHEN', 'vinoharstephenrapheal.bt@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('310', 'SETHURAMAN', 'gsethukarthi@yahoo.co.in', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('311', 'ARUL', 'arul_anamalai@yahoo.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('312', 'AROKIA LAWRENCE VIJAY', 'vijay44u@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('313', 'ANITH PREM MALARAVAN', 'prem3138@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('314', 'SRIKALA', 'sriku12@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('315', 'MYTHILI', 'mythilibharat@rediffmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('316', 'MEENA PRIYADARSHINI', 'meenu_smp@rediffmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('317', 'MEENA', 'meenarajarajan@yahoo.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('318', 'MAHALAKSHMI', 'mahalnet@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('319', 'KRISHNA MOORTHY', 'krishnamoorthykct@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('32', 'BASKAR', 'baskar.r.bt@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('320', 'TISSAA TONY', 'tissaatonyc@yahoo.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('321', 'RAJASINGH', 'rajasinghjacob@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('322', 'KARTHIK', 'karthikchemics84@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('323', 'RATHINA', 'rathina1008@rediffmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('324', 'ARIVUOLI', 'arivuolisundar@yahoo.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('325', 'RAJKUMAR', 'rajkumar_raj2000@yahoo.co.in', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('326', 'KRISHNAMURTHY', 'krishna69_v@yahoo.co.in', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('327', 'INBAKUMAR', 's.inbakumar@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('328', 'ABIRAMI', 'abirami.vivek@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('329', 'ARANGANAYAGAM', 'aranganayagam@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('33', 'KUMARESAN', 'kumaresan.k.bt@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('330', 'SUGANDHI', 'suganthik76@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('331', 'THILAGAVATHY', 'kp_thilagavathy_22@yahoo.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('332', 'JALAJAA', 'jalajaaharsha@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('333', 'ANBHUVIZHI', 'anbhums@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('334', 'SHANMUGHAVADIVU', 'shanmughavadivua@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('335', 'NIRMALA DEVI', 'nirmaladravi@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('336', 'SELVAMBIKAI', 'selvambikai@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('337', 'RATHIDEVI', 'rathichem@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('338', 'DHIVYA', 'dhivya.j.sci@kct.ac.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('339', 'SARATHA', 'ammusaratha@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('34', 'SATHISH KUMAR', 'sathiskumar.t.bt@kct.ac.in', 'Male', 'ASST PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('340', 'MOHANRAJ', 'sgmohanraj@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('341', 'KALAPRIYA', 'kalapriyaa@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('342', 'NITHYA', 'nithi_mathu@yahoo.co.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('343', 'SAMPATH', 'sampathchemistry@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('344', 'DANIEL', 'daniechem61@gmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('345', 'SREEJANA', 'sreejanasasikumar@gmail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('346', 'SHOBHANA', 'shobhana.r.sci@kct.ac.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('347', 'MAHESWARI', 'kmegamaths@yahoo.co.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('348', 'EZHILARASI', 'ezhilmagi@yahoo.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('349', 'HEMA', 'hema.chandru@ymail.com', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('35', 'MANIMARAN', 'manimaran.d.r.bt@kct.ac.in', 'Male', 'ASST PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('350', 'ARUNADEVI', 'arunadevi.s.sci@kct.ac.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('351', 'JYOTHI', 'jyothi.sci@kct.ac.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('352', 'PRAKASAM', 'prakasam80@rediffmail.com', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('353', 'KANNAN', 'kannan.r.sci@kct.ac.in', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('354', 'ARUL', 'arul.h.sci@kct.ac.in', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('355', 'VIJETA', 'vijetaiyer.sci@kct.ac.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('356', 'ASHOKKUMAR', 'ashokkumar.r.sci@kct.ac.in', 'Male', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('357', 'ANITHA', 'anitha.n.sci@kct.ac.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('358', 'MYTHILI', 'mythili.as.sci@kct.ac.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('359', 'KALPANA', 'kalpana.n.sci@kct.ac.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('36', 'NITHYAPRIYA', 'nithyapriya.s.bt@kct.ac.in', 'Female', 'ASST PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('360', 'PRINCY FLORA', 'princyflora.m.sci@kct.ac.in', 'Female', 'ASST PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('361', 'ARUNACHALAM', 'tarun_chalam@yahoo.com', 'Male', 'PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('362', 'HYACINTH', 'hyacinthpink..sci@kct.ac.in', 'Female', 'PROFESSOR', 'FIRST YEAR/OTHER', 1234567891, ''),
('37', 'MUTHUKUMARAN', 'muthukumaran.p.bt@kct.ac.in', 'Male', 'ASST PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('38', 'THIRUMURUGAN', 'thirumurugan.a.bt@kct.ac.in', 'Male', 'ASST PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('39', 'SIVARAJASEKAR', 'sivarajasekar.n.bt@kct.ac.in', 'Male', 'ASST PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('4', 'SENTHIL KUMAR', 'senthilkumar.m.aeu@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('40', 'VEERA BHUVANESHWARI', 'veerabhuvaneshwari.v.bt@kct.ac.in', 'Female', 'ASST PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('41', 'RAMALINGAM', 'ramalingam.p.bt@kct.ac.in', 'Male', 'PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('42', 'RAM', 'ram.k.bt@kct.ac.in', 'Male', 'ASST PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('43', 'KUMARAVEL', 'kumaravel.k.bt@kct.ac.in', 'Male', 'ASST PROFESSOR', 'BIOTECHNOLOGY', 1234567891, ''),
('44', 'PREMALATHA', 'hod.civil@kct.ac.in', 'Female', 'PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('45', 'RAMADEVI', 'ramadevi.k.ce@kct.ac.in', 'Female', 'PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('46', 'GANDHIMATHI', 'gandhimathi.a.ce@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('47', 'RAMSUNDRAM', 'ramsundram.civil@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('48', 'GAYATHRI', 'gayathri.v.ce@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('49', 'SELVAN', 'selvan.v.ce@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('5', 'ARUN KUMAR', 'arunkumar.r.aeu@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('50', 'KARTHIKEYAN', 'karthikeyan.s.ce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('51', 'SENTHILKUMAR', 'senthilkumar.v.ce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('52', 'LISA MARY', 'lisamary.ce@kct.ac.in', 'Female', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('53', 'NANDHAKUMAR', 'nandhakumar.p.ce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('54', 'VISHNU', 'vishnu.a.ce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('55', 'KARTHIKEYAN', 'karthikeyan.g.ce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('56', 'SHIVARANJANI', 'shivaranjani.sk.ce@kct.ac.in', 'Female', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('57', 'RAJALAKSHMI', 'raji_devaraj@yahoo.co.in', 'Female', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('58', 'ANITA', 'anita.s.ce@kct.ac.in', 'Female', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('59', 'SACHIN PRABHU', 'sachinprabhu.ce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('6', 'DARSHAN KUMAR', 'darshankumar.j.aeu@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('60', 'PRABAKARAN', 'prabakaran.pa.ce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('6001', 'Santhiya D', 'santhiya.17cs@kct.ac.in', 'Female', 'student', 'cse', 8870151621, '6001.png'),
('61', 'VISWANATH', 'viswanath.j.ce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('62', 'ANAND', 'anand.t.ce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('63', 'NISHAANT', 'nishaant.ha.ce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'CIVIL ENGINEERING', 1234567891, ''),
('64', 'ESWARAMOORTHI', 'eswaramoorthi.p.ce@kct.ac.in', 'Male', 'PROFESSOR', 'STRUCTURAL ENGINEERING', 1234567891, ''),
('65', 'MANJU', 'manju.r.ce@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'STRUCTURAL ENGINEERING', 1234567891, ''),
('66', 'SATHEESH KUMAR', 'satheeshkumar.krp.ce@kct.ac.in', 'Male', 'ASST PROFESSOR', 'STRUCTURAL ENGINEERING', 1234567891, ''),
('67', 'SATHYA MOORTHY', 'sathyamoorthy.g.l.ce@kct.ac.in', 'Male', 'PROFESSOR', 'ENVIRONMENTAL ENGINEERING', 1234567891, ''),
('68', 'GEETHAKARTHI', 'geethakarthi.a.ce@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'ENVIRONMENTAL ENGINEERING', 1234567891, ''),
('69', 'JAMUNA', 'jamuna.m.ce@kct.ac.in', 'Female', 'ASST PROFESSOR', 'ENVIRONMENTAL ENGINEERING', 1234567891, ''),
('7', 'ARULPRAKASH', 'arulprakash.r.aeu@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('70', 'DEVAKI', 'devaki_cbe4@yahoo.com', 'Female', 'PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('71', 'CYNTHIA', 'cynthia.j.it@kct.ac.in', 'Female', 'PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('72', 'SUGANTHI', 'suganthi.n.it@kct.ac.in', 'Female', 'PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('73', 'LATHA', 'surlatha@yahoo.com', 'Female', 'PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('74', 'VIMAL', 'vimal.ea.it@kct.ac.in', 'Male', 'ASSOCIATE PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('75', 'SUMATHI', 'sumathi_subbu2001@yahoo.co.in', 'Female', 'ASSOCIATE PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('76', 'SATHYA', 'sathya.d.cse@kct.ac.in', 'Female', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('77', 'NITHYA ROOPA', 'nithyaroopa@gmail.com', 'Female', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('78', 'ASWINI', 'aswini.d.cse@kct.ac.in', 'Female', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('79', 'SENTHIL KUMAR', 'senthilkumar.v.cse@kct.ac.in', 'Male', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('8', 'SENTHIL KUMAR', 'senthilkumar.s.aero@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('80', 'FRANCIS JENCY', 'jenijeni89@gmail.com', 'Female', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('81', 'KANAGARAJ', 'kanagaraj.g.cse@kct.ac.in', 'Male', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('82', 'UMA MAHESWARI', 'umamaheswari.s.cse@kct.ac.in', 'Female', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('83', 'YAMUNATHANGAM', 'yamunathangam.d.cse@kct.ac.in', 'Female', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('84', 'JEBA', 'jeba.n.cse@kct.ac.in', 'Female', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('85', 'KIRUBAKARAN', 'kirubakaran.r.cse@kct.ac.in', 'Male', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('86', 'SYED ALI FATHIMA', 'syedalialifathima.sj.cse@kct.ac.in', 'Female', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('87', 'BHARATHI PRIYA', 'bharathipriya.c.cse@kct.ac.in', 'Female', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('88', 'THIRUVAAZHI', 'thiruvaazhi.u.cse@kct.ac.in', 'Male', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('89', 'SUDHA', 'sudha.v.cse@kct.ac.in', 'Female', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('9', 'NAVEENKUMAR', 'naveenkumar.k.aeu@kct.ac.in', 'Male', 'ASST PROFESSOR', 'AERONAUTICAL ENGINEERING', 1234567891, ''),
('90', 'CHANDRAKALA', 'vishnuchandra2003@yahoo.com', 'Female', 'PROFESSOR', 'INFORMATION SCIENCE AND ENGINEERING', 1234567891, ''),
('91', 'SUGUNA', 'suguna.m.cse@kct.ac.in', 'Female', 'ASSOCIATE PROFESSOR', 'INFORMATION SCIENCE AND ENGINEERING', 1234567891, ''),
('92', 'SATHYAVATHI', 'sathyavathi.s.it@kct.ac.in', 'Female', 'ASST PROFESSOR', 'INFORMATION SCIENCE AND ENGINEERING', 1234567891, ''),
('93', 'SHOBANA', 'shobana.g.cse@kct.ac.in', 'Female', 'ASST PROFESSOR', 'INFORMATION SCIENCE AND ENGINEERING', 1234567891, ''),
('94', 'SARANYA', 'saranya.k.cse@kct.ac.in', 'Female', 'ASST PROFESSOR', 'INFORMATION SCIENCE AND ENGINEERING', 1234567891, ''),
('95', 'KALAISELVI', 'kalaiselvi.r.cse@kct.ac.in', 'Female', 'ASST PROFESSOR', 'INFORMATION SCIENCE AND ENGINEERING', 1234567891, ''),
('96', 'BASKARAN', 'baskaran.kr.it@kct.ac.in', 'Male', 'PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('97', 'RAJINI', 'sraj_10@yahoo.com', 'Female', 'ASSOCIATE PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('98', 'SIDDIQUE IBRAHIM', 'siddique4x@gmail.com', 'Male', 'ASST PROFESSOR', 'COMPUTER SCIENCE AND ENGINEERING', 1234567891, ''),
('99', 'MALARVIZHI', 'malarvizhi.k.ece@kct.ac.in', 'Female', 'PROFESSOR', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 1234567891, ''),
('K01462', 'Subramaniam G', 'subramaniam.g.kciri@kct.ac.in', 'Male', 'Project Engineer', 'KCIRI', 0, 'subramaniam.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `resetpasswords`
--

CREATE TABLE `resetpasswords` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `temp_apr`
--

CREATE TABLE `temp_apr` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_apr`
--

INSERT INTO `temp_apr` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-04-21 09:29:31', '100', 7, '1'),
('2', 'subramaiam@kct.ac.in', '2020-04-12 01:59:31', '96', 8.2, '1'),
('3', 'vignesh@kct.ac.in', '2020-04-10 03:29:31', '107', 8.2, '2'),
('4', 'sanalkumar@kct.ac.in', '2020-04-18 04:29:31', '98', 8.2, '3');

-- --------------------------------------------------------

--
-- Table structure for table `temp_aug`
--

CREATE TABLE `temp_aug` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_aug`
--

INSERT INTO `temp_aug` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-08-21 11:29:31', '98', 7.5, '3'),
('100', 'nirmalkumar.a@kct.ac.in', '2020-08-12 06:29:31', '96', 7.9, '3'),
('4', 'sanalkumar@kct.ac.in', '2020-08-11 04:29:31', '98', 8.2, '2');

-- --------------------------------------------------------

--
-- Table structure for table `temp_dec`
--

CREATE TABLE `temp_dec` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_dec`
--

INSERT INTO `temp_dec` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-12-21 02:29:31', '100', 7.8, '1'),
('109', '	 jrameee@gmail.com', '2020-12-12 06:29:31', '100', 7.5, '2'),
('4', 'sanalkumar@kct.ac.in', '2020-12-02 02:29:31', '96', 8.2, '1');

-- --------------------------------------------------------

--
-- Table structure for table `temp_feb`
--

CREATE TABLE `temp_feb` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_feb`
--

INSERT INTO `temp_feb` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-02-20 11:29:31', '110', 8, '3'),
('111', 'sureshpls45@yahoo.co.in', '2020-02-13 06:29:31', '96', 7.8, '3'),
('2', 'subramaiam@kct.ac.in', '2020-02-11 01:49:31', '100', 8.3, '1'),
('3', 'vignesh@kct.ac.in', '2020-02-10 01:29:31', '107', 8.5, '3'),
('4', 'sanalkumar@kct.ac.in', '2020-02-22 10:29:31', '97', 8.2, '2'),
('81', 'kanagaraj.g.cse@kct.ac.in', '2020-02-27 06:29:31', '105', 8.1, '1');

-- --------------------------------------------------------

--
-- Table structure for table `temp_jan`
--

CREATE TABLE `temp_jan` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_jan`
--

INSERT INTO `temp_jan` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-01-12 10:29:31', '96', 8, '1'),
('106', 'prakashnarayanasamy@yahoo.com', '2020-01-17 07:29:31', '96', 7.7, '3'),
('2', 'subramaniam@.kct.ac.in', '2020-01-13 12:29:31', '99', 7.5, '2'),
('3', 'vignesh@kct.ac.in', '2020-01-13 02:29:31', '98', 7.5, '3'),
('4', 'sanalkumar@kct.ac.in', '2020-01-14 03:29:31', '105', 7.5, '3');

-- --------------------------------------------------------

--
-- Table structure for table `temp_jul`
--

CREATE TABLE `temp_jul` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_jul`
--

INSERT INTO `temp_jul` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-07-21 11:29:31', '103', 7.5, '2'),
('4', 'sanalkumar@kct.ac.in', '2020-07-10 04:29:31', '98', 8.2, '3');

-- --------------------------------------------------------

--
-- Table structure for table `temp_jun`
--

CREATE TABLE `temp_jun` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_jun`
--

INSERT INTO `temp_jun` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-06-21 10:29:31', '103', 7, '1'),
('2', 'subramaiam@kct.ac.in', '2020-06-15 05:59:31', '100', 7.5, '2'),
('3', 'vignesh@kct.ac.in', '2020-06-10 02:29:31', '100', 8.5, '1'),
('4', 'sanalkumar@kct.ac.in', '2020-06-18 04:29:31', '98', 8.2, '3'),
('80', 'jenijeni89@gmail.com', '2020-06-12 03:29:31', '100', 7.7, '2');

-- --------------------------------------------------------

--
-- Table structure for table `temp_mar`
--

CREATE TABLE `temp_mar` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_mar`
--

INSERT INTO `temp_mar` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-03-21 02:29:31', '100', 7.5, '1'),
('2', 'subramaiam@kct.ac.in', '2020-03-11 02:49:31', '110', 8.5, '2'),
('3', 'vignesh@kct.ac.in', '2020-03-10 01:29:31', '107', 8.5, '1');

-- --------------------------------------------------------

--
-- Table structure for table `temp_may`
--

CREATE TABLE `temp_may` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_may`
--

INSERT INTO `temp_may` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-05-21 02:29:31', '98', 7.5, '1'),
('2', 'subramaiam@kct.ac.in', '2020-05-14 05:49:31', '110', 7.5, '3'),
('3', 'vignesh@kct.ac.in', '2020-05-10 02:29:31', '100', 8.5, '1');

-- --------------------------------------------------------

--
-- Table structure for table `temp_nov`
--

CREATE TABLE `temp_nov` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_nov`
--

INSERT INTO `temp_nov` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-11-21 12:29:31', '100', 8.5, '3'),
('109', 'jrameee@gmail.com', '2020-11-12 06:29:31', '100', 7.7, '3'),
('4', 'sanalkumar@kct.ac.in', '2020-11-02 02:29:31', '96', 8.2, '2');

-- --------------------------------------------------------

--
-- Table structure for table `temp_oct`
--

CREATE TABLE `temp_oct` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_oct`
--

INSERT INTO `temp_oct` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-10-21 11:29:31', '98', 7.5, '3'),
('4', 'sanalkumar@kct.ac.in', '2020-10-11 02:29:31', '100', 8.2, '3');

-- --------------------------------------------------------

--
-- Table structure for table `temp_sep`
--

CREATE TABLE `temp_sep` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `temperature` decimal(10,0) NOT NULL,
  `distance` float NOT NULL,
  `shift` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_sep`
--

INSERT INTO `temp_sep` (`uid`, `email`, `time`, `temperature`, `distance`, `shift`) VALUES
('1', 'rameshselvakumar@kct.ac.in', '2020-09-21 12:29:31', '98', 7.2, '2'),
('4', 'sanalkumar@kct.ac.in', '2020-09-11 04:29:31', '100', 8.2, '2'),
('5', 'kumar@kct.ac.in', '2020-09-25 04:50:00', '100', 8.3, '2'),
('55', 'kumar@kct.ac.in', '2020-09-25 06:29:31', '96', 7.7, '3'),
('6001', 'kumar@gmail.com', '2020-09-26 06:29:31', '96', 7.7, '3'),
('6002', 'kumar@gmail.com', '2020-09-27 06:29:31', '96', 7.7, '3'),
('6003', 'kumar@gmail.com', '2020-09-02 00:00:00', '96', 7.7, '3');

-- --------------------------------------------------------

--
-- Table structure for table `test_img`
--

CREATE TABLE `test_img` (
  `img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` varchar(6) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `token` varchar(10) NOT NULL,
  `tokenExpire` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `email`, `password`, `token`, `tokenExpire`) VALUES
('1', 'sanalkumar.vr.aeu@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('10', 'rajkumar.g.aeu@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('100', 'nirmalkumar.a@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('101', 'haiudhaya@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('102', 'kppremalatha@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('103', 'kavithain2@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('104', 'mmrguru@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('105', 'karunamoorthy.b.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('106', 'prakashnarayanasamy@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('107', 'm.nirmala.gct@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('108', 'shanthits@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('109', 'jrameee@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('11', 'vijayanandh.r.aeu@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('110', 'kalies.me@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('111', 'sureshpls45@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('112', 'sandhyars2003@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('113', 'anushree.g.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('114', 'sharmitha.d.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('115', 'balaji.vr.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('116', 'viswanathan.t.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('117', 'dinesh161190@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('118', 'mohanasundaram.n.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('119', 'arunkumar.s.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('12', 'muthukumar.s.aero@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('120', 'sasikumar.c.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('121', 'suryaprakash.s.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('122', 'vinothkumar.n.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('123', 'paramasivam.k.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('124', 'bickandha@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('125', 'mathankumar.m.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('126', 'thirumoorthi.p.eee@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('127', 'maitheerainbow@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('128', 'govindaraju.s.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('129', 'hod.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('13', 'kiruthika.s.kciri@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('130', 'anilkumar.kk.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('131', 'mayurappriyan.ps.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('132', 'dineshkumar.v.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('133', 'umesh.mv.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('134', 'jeyadaisy.i.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('135', 'athappan.v.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('136', 'muthuramalingam.e.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('137', 'manimekalai.v.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('138', 'saravanabalaji.m.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('139', 'saravanakumar.s.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('14', 'balaji.k.kciri@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('140', 'ranganathan.s.eie@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('141', 'ramprakash.k.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('142', 'ramalatha.m.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('143', 'pasupathy.sa.mce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('144', 'kavitha.k.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('145', 'amsaveni.a.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('146', 'shanthi.m.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('147', 'hemakct@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('148', 'umarajaslm@sifymail.com', 'abc123', '', '0000-00-00 00:00:00'),
('149', 'sasikala.s.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('15', 'sivakumar.s.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('150', 'shivappriya.sn.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('151', 'darwinr@ymail.com', 'abc123', '', '0000-00-00 00:00:00'),
('152', 'karthikeyan.r.ece@kct.ac.inmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('153', 'rdhivyaktp@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('154', 'kalaiselvi.a.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('155', 'jasminejenil@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('156', 'umakce16@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('157', 'anusha.k.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('158', 'karthik.s.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('159', 'krisan80@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('16', 'thenmozhi.g.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('160', 'alinjoe.d.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('161', 'karthikumar.r.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('162', 'chandruece89@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('163', 'shijishajahan@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('164', 'navaneethakrishnan.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('165', 'karthika.k.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('166', 'david.s.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('167', 'jasparvinithasundari.t.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('168', 'arunkumar.s.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('169', 'ashwini.a.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('17', 'karthik.t.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('170', 'timothy.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('171', 'ajay.vp.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('172', 'tamilelakkiya.s.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('173', 'bharathi.m.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('174', 'alagu_meenakshi@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('175', 'thilagavathi.k.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('176', 'ranithottungal@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('177', 'rathina2k@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('178', 'bhaarathi_dhurai@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('179', 'rraajj80@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('18', 'andrew.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('180', 'krishnassstyle@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('181', 'radhakrishnanshanthi@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('182', 'elitechandru@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('183', 's_kavishna@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('184', '2arunraj@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('185', 'prabukrishnaa@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('186', 'rvraju23@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('187', 'g.ramki15@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('188', 'cssentthil@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('189', 'athambidurai@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('19', 'saiganesh.j.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('190', 'vanitha.v.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('191', 'vijilesh.v.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('192', 'nandakumar.gs.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('193', 'alamelu.m.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('194', 'shenbagam.p.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('195', 'kanagaraj.s.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('196', 'premaarokiamary.g.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('197', 'suresh.a.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('198', 'hariprasath.l.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('199', 'saroja.mn.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('2', 'sundararaj.k.aeu@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('20', 'satish.s.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('200', 'rajathi.n.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('201', 'kavitha.s.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('202', 'vrn@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('203', 'marycherian@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('204', 'swaminathan@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('205', 'kannan@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('206', 'sangisubramanian@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('207', 'profvkk@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('208', 'kirupa@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('209', 'rvs@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('21', 'kishore.r.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('210', 'jaisankar@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('211', 'placement@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('212', 'deepa@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('213', 'poongodi@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('214', 'lathakamalesh@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('215', 'mohanamani@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('216', 'nalini@kctbs.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('217', 'geethasuresh@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('218', 'mani_dpm@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('219', 'jv_prakash@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('22', 'rajkumar.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('220', 'ibuhum@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('221', 'rk_kavitha@ymail.com', 'abc123', '', '0000-00-00 00:00:00'),
('222', 'p_param@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('223', 'shyamkrupa@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('224', 'haijai2@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('225', 'mcsgeetha@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('226', 'vjalaja79@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('227', 'amalawithcontact@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('228', 'dhanabal.l.mca@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('229', 'chandrurgp@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('23', 'naveenkumar.c.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('230', 'jaisinghw@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('231', 'velmurugan.c.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('232', 'muthukumaran.v.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('233', 'manivel.r.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('234', 'muruganantham.vr.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('235', 'thirumurugaveerakumar.s.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('236', 'balaji.m.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('237', 'senthilkumar.b.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('238', 'sangeetha.n.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('239', 'senthilkumar.km.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('24', 'prabhakaran.a.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('240', 'balasubramanian.s.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('241', 'arun.kk.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('242', 'sivakumar.s.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('243', 'ayyappan.pr.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('244', 'arun.ap.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('245', 'manivelmuralidaran.v.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('246', 'ulaganathan.k.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('247', 'balaji.s.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('248', 'prabhu.s.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('249', 'krishnamoorthi.k.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('25', 'arun.b.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('250', 'rameshkumar.m.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('251', 'rajesh.s.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('252', 'mohankumar.rs.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('253', 'navaneeth.vr.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('254', 'samuelratnakumar.ps.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('255', 'prabhusubramaniam.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('256', 'lakshmanan.ks@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('257', 'jeeva.b.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('258', 'subbiah.s.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('259', 'pradeep.p.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('26', 'mohankumar.s.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('260', 'karthi.p.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('261', 'devan.pd.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('262', 'prashanth.p.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('263', 'karuppusamy.t.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('264', 'sivakumar.siddhan.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('265', 'suresh.s.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('266', 'vinayagamoorthi.ma.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('267', 'ramanathan.s.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('268', 'sreeharan.b.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('269', 'ananth.kr@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('27', 'vasantharaj.c@kct.ac.inm', 'abc123', '', '0000-00-00 00:00:00'),
('270', 'kiranlal.s@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('271', 'sathyabalan.p.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('272', 'sukumar.tr.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('273', 'manikandaprasath.k.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('274', 'bhaskar.s.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('275', 'thirumalaimuthukumaran.m.mec@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('276', 'vasuki.a.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('277', 'venkatesan.r.mce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('278', 'akila.k.mce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('279', 'saravanamohan.m.mce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('28', 'johnalexis.s.auto@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('280', 'sabitha.b.mce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('281', 'ramkumar.a.mce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('282', 'suresh.t.mce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('283', 'raffikkmrs@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('284', 'saravanan.r.mce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('285', 'magudapathi.p.mce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('286', 'anush.p.mce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('287', 'ack.murugan@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('288', 'sivaguru.j.mce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('289', 'mdhinakaran2000@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('29', 'saraswathy.n.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('290', 'salemramesh@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('291', 'chans_sekar@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('292', 'natarajanex@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('293', 'sivasivaa123@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('294', 'ariharasudhan@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('295', 'saravanan.m.txt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('296', 'ssukanyas@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('297', 'srinivasan.j.ft@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('298', 'ktmanithanga@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('299', 'shobsundar@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('3', 'premkumar.ps.aeu@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('30', 'shanmugaprakash.m.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('300', 'thangeswaran_pt@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('301', 'santha_jsk@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('302', 'ussche@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('303', 'marudhu14@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('304', 'mayildurai@redifmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('305', 'sivaharir@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('306', 'sengodan78@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('307', 'kctbala@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('308', 'ss_sakthimaths@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('309', 'selva_sanju@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('31', 'vinoharstephenrapheal.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('310', 'gsethukarthi@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('311', 'arul_anamalai@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('312', 'vijay44u@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('313', 'prem3138@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('314', 'sriku12@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('315', 'mythilibharat@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('316', 'meenu_smp@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('317', 'meenarajarajan@yahoo.in', 'abc123', '', '0000-00-00 00:00:00'),
('318', 'mahalnet@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('319', 'krishnamoorthykct@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('32', 'baskar.r.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('320', 'tissaatonyc@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('321', 'rajasinghjacob@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('322', 'karthikchemics84@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('323', 'rathina1008@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('324', 'arivuolisundar@yahoo.in', 'abc123', '', '0000-00-00 00:00:00'),
('325', 'rajkumar_raj2000@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('326', 'krishna69_v@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('327', 's.inbakumar@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('328', 'abirami.vivek@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('329', 'aranganayagam@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('33', 'kumaresan.k.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('330', 'suganthik76@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('331', 'kp_thilagavathy_22@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('332', 'jalajaaharsha@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('333', 'anbhums@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('334', 'shanmughavadivua@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('335', 'nirmaladravi@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('336', 'selvambikai@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('337', 'rathichem@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('338', 'dhivya.j.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('339', 'ammusaratha@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('34', 'sathiskumar.t.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('340', 'sgmohanraj@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('341', 'kalapriyaa@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('342', 'nithi_mathu@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('343', 'sampathchemistry@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('344', 'daniechem61@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('345', 'sreejanasasikumar@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('346', 'shobhana.r.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('347', 'kmegamaths@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('348', 'ezhilmagi@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('349', 'hema.chandru@ymail.com', 'abc123', '', '0000-00-00 00:00:00'),
('35', 'manimaran.d.r.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('350', 'arunadevi.s.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('351', 'jyothi.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('352', 'prakasam80@rediffmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('353', 'kannan.r.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('354', 'arul.h.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('355', 'vijetaiyer.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('356', 'ashokkumar.r.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('357', 'anitha.n.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('358', 'mythili.as.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('359', 'kalpana.n.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('36', 'nithyapriya.s.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('360', 'princyflora.m.sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('361', 'tarun_chalam@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('362', 'hyacinthpink..sci@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('37', 'muthukumaran.p.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('38', 'thirumurugan.a.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('39', 'sivarajasekar.n.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('4', 'senthilkumar.m.aeu@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('40', 'veerabhuvaneshwari.v.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('41', 'ramalingam.p.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('42', 'ram.k.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('43', 'kumaravel.k.bt@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('44', 'hod.civil@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('45', 'ramadevi.k.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('46', 'gandhimathi.a.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('47', 'ramsundram.civil@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('48', 'gayathri.v.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('49', 'selvan.v.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('5', 'arunkumar.r.aeu@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('50', 'karthikeyan.s.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('51', 'senthilkumar.v.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('52', 'lisamary.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('53', 'nandhakumar.p.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('54', 'vishnu.a.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('55', 'karthikeyan.g.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('56', 'shivaranjani.sk.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('57', 'raji_devaraj@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('58', 'anita.s.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('59', 'sachinprabhu.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('6', 'darshankumar.j.aeu@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('60', 'prabakaran.pa.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('61', 'viswanath.j.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('62', 'anand.t.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('63', 'nishaant.ha.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('64', 'eswaramoorthi.p.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('65', 'manju.r.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('66', 'satheeshkumar.krp.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('67', 'sathyamoorthy.g.l.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('68', 'geethakarthi.a.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('69', 'jamuna.m.ce@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('7', 'arulprakash.r.aeu@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('70', 'devaki_cbe4@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('71', 'cynthia.j.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('72', 'suganthi.n.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('73', 'surlatha@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('74', 'vimal.ea.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('75', 'sumathi_subbu2001@yahoo.co.in', 'abc123', '', '0000-00-00 00:00:00'),
('76', 'sathya.d.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('77', 'nithyaroopa@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('78', 'aswini.d.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('79', 'senthilkumar.v.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('8', 'senthilkumar.s.aero@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('80', 'jenijeni89@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('81', 'kanagaraj.g.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('82', 'umamaheswari.s.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('83', 'yamunathangam.d.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('84', 'jeba.n.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('85', 'kirubakaran.r.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('86', 'syedalialifathima.sj.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('87', 'bharathipriya.c.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('88', 'thiruvaazhi.u.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('89', 'sudha.v.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('9', 'naveenkumar.k.aeu@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('90', 'vishnuchandra2003@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('91', 'suguna.m.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('92', 'sathyavathi.s.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('93', 'shobana.g.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('94', 'saranya.k.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('95', 'kalaiselvi.r.cse@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('96', 'baskaran.kr.it@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('97', 'sraj_10@yahoo.com', 'abc123', '', '0000-00-00 00:00:00'),
('98', 'siddique4x@gmail.com', 'abc123', '', '0000-00-00 00:00:00'),
('99', 'malarvizhi.k.ece@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00'),
('999', 'yamunaravi36@gmail.com', 'abc123', '', '2020-08-19 20:37:07'),
('K01462', 'subramaniam.g.kciri@kct.ac.in', 'abc123', '', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `resetpasswords`
--
ALTER TABLE `resetpasswords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `temp_apr`
--
ALTER TABLE `temp_apr`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `temp_aug`
--
ALTER TABLE `temp_aug`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `temp_dec`
--
ALTER TABLE `temp_dec`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `temp_feb`
--
ALTER TABLE `temp_feb`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `temp_jan`
--
ALTER TABLE `temp_jan`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `temp_jul`
--
ALTER TABLE `temp_jul`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `temp_jun`
--
ALTER TABLE `temp_jun`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `temp_mar`
--
ALTER TABLE `temp_mar`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `temp_may`
--
ALTER TABLE `temp_may`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `temp_nov`
--
ALTER TABLE `temp_nov`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `temp_oct`
--
ALTER TABLE `temp_oct`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `temp_sep`
--
ALTER TABLE `temp_sep`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `resetpasswords`
--
ALTER TABLE `resetpasswords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
