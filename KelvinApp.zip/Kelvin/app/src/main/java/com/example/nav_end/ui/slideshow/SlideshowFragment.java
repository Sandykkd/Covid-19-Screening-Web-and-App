package com.example.nav_end.ui.logout;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.nav_end.LoginActivity;
import com.example.nav_end.R;
import com.example.nav_end.SharedPrefManager;

import android.content.SharedPreferences;
import android.widget.Toast;


public class SlideshowFragment extends Fragment {
    Activity context;
    Button logout_bt;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        View pass_view =  inflater.inflate(R.layout.fragment_slideshow,container,false);

        logout_bt = pass_view.findViewById(R.id.btn_logout);

        logout_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("temperaturesharedpref", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear();
                editor.apply();
                getActivity().finish();
                getActivity().startActivity(new Intent(getActivity(), LoginActivity.class));

            }
        });
        return pass_view;
    }

}