package com.example.nav_end;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.WindowManager;
import android.widget.TextView;

public class SplashActivity extends AppCompatActivity {

    TextView name,kciri;
    private static  int SPLASH_TIME_OUT=1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        name = findViewById(R.id.name);
        kciri = findViewById(R.id.kciri);
        name.setText(Html.fromHtml("<b>K</b>umaraguru <b>E</b>mployee <b>L</b>ive <b>V</b>erification and <b>I</b>dentificatio<b>N</b>"));
        kciri.setText(Html.fromHtml("Developed by Team <b>KC.IRI</b>"));



        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //if the user is already logged in we will directly start the main activity
                if (SharedPrefManager.getInstance(SplashActivity.this).isLoggedIn()) {
                    finish();
                    startActivity(new Intent(SplashActivity.this, MainActivity.class));
                    return;
                }
                else {
                    Intent homeIntent = new Intent(SplashActivity.this, LoginActivity.class);
                    startActivity(homeIntent);
                    finish();
                }

            }
        },SPLASH_TIME_OUT);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN ,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }
}
