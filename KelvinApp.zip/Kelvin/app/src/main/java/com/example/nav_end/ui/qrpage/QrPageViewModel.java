package com.example.nav_end.ui.qrpage;

import androidx.lifecycle.ViewModel;

public class QrPageViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
