package com.example.nav_end;

public class User {
    private String name,email,dept,gender,designation,mobile,id,photo;
   // public User(String id, String username,String name,String dept,String gender,String designation,String mobile) {

    public User(String id, String email,String name,String gender,String designation,String dept,String mobile,String photo) {
        this.id = id;
        this.email = email;
        this.name = name;
        this.dept =dept;
        this.gender = gender;
        this.designation = designation;
        this.mobile = mobile;
        this.photo=photo;
    }

    public String getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }


    public String getName() {
        return name;
    }

    public String getDept() {
        return dept;
    }


    public String getGender() {
        return gender;
    }

    public String getDesignation() {
        return designation;
    }

    public String getMobile() {
        return mobile;
    }

    public String getPhoto(){return photo;}
}


