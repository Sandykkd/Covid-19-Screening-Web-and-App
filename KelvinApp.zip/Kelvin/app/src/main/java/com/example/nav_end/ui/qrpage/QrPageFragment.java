package com.example.nav_end.ui.qrpage;

import androidmads.library.qrgenearator.QRGContents;
import androidmads.library.qrgenearator.QRGEncoder;
import androidx.lifecycle.ViewModelProviders;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.nav_end.MainActivity;
import com.example.nav_end.R;
import com.example.nav_end.SharedPrefManager;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import static android.content.Context.WINDOW_SERVICE;




public class QrPageFragment extends Fragment {


    ImageView image;
    String text2Qr,email,password,dept,name,id;
    TextView value;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View qrcode_view =  inflater.inflate(R.layout.qr_page_fragment,container,false);
        email = SharedPrefManager.getInstance(getActivity()).getUser().getEmail();
        id=SharedPrefManager.getInstance(getActivity()).getUser().getId();
        //password=SharedPrefManager.getInstance(getActivity()).getUser().getPassword();
        name=SharedPrefManager.getInstance(getActivity()).getUser().getName();
        //Toast.makeText(getActivity()," Pass" + SharedPrefManager.getInstance(getActivity()).getUser().getPassword(), Toast.LENGTH_SHORT).show();

        //Toast.makeText(getActivity()," " + name, Toast.LENGTH_SHORT).show();

        //Toast.makeText(getActivity(),"Name " + SharedPrefManager.getInstance(getActivity()).getUser().getName(), Toast.LENGTH_SHORT).show();

        image = qrcode_view.findViewById(R.id.image);
        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
        try{


            BitMatrix bitMatrix = multiFormatWriter.encode(email+"\n"+id, BarcodeFormat.QR_CODE,200,200);
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
            image.setImageBitmap(bitmap);
        }
        catch (WriterException e){
            e.printStackTrace();
        }

        value = qrcode_view.findViewById(R.id.value);

        value.setText("      "+email);



        return qrcode_view;
    }

}
