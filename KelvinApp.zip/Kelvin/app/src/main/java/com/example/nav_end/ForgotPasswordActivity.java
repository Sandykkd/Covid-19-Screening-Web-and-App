package com.example.nav_end;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class ForgotPasswordActivity extends AppCompatActivity {
    Button button;
    TextView textView;
    EditText editText;
    String emailstr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        button=(Button)findViewById(R.id.bn);
        textView=(TextView)findViewById(R.id.txt);
        editText=(EditText)findViewById(R.id.email);
        final String server_url="http://192.168.43.123/sandy_temp/sendmail1.php";
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emailstr=editText.getText().toString();
                Toast.makeText(getApplicationContext(),"Sending Mail",Toast.LENGTH_LONG).show();
                //Toast.makeText(getApplicationContext(),"Please wait...",Toast.LENGTH_LONG).show();
                final RequestQueue requestQueue= Volley.newRequestQueue(ForgotPasswordActivity.this);
                StringRequest stringRequest=new StringRequest(Request.Method.POST,server_url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                textView.setText(response);


                                requestQueue.stop();

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        if( error instanceof NetworkError) {
                            textView.setText("NetworkError");
                            //handle your network error here.
                        } else if( error instanceof ServerError) {
                            textView.setText("ServerError");
                            //handle if server error occurs with 5** status code
                        } else if( error instanceof AuthFailureError) {
                            textView.setText("AuthFailError");
                            //handle if authFailure occurs.This is generally because of invalid credentials
                        } else if( error instanceof ParseError) {
                            textView.setText("ParseError");
                            //handle if the volley is unable to parse the response data.
                        } else if( error instanceof NoConnectionError) {
                            textView.setText("NoConnectionError");
                            //handle if no connection is occurred
                        } else if( error instanceof TimeoutError) {
                            textView.setText("TimeoutError");
                            //handle if socket time out is occurred.
                        }
                        requestQueue.stop();

                    }
                }){
                    @Override
                    protected Map<String,String> getParams() {
                        Map<String,String> params=new HashMap<String,String>();
                        params.put("str_mail",emailstr);
                        return params;

                    }
                };
                stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                        25000,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                requestQueue.add(stringRequest);



            }
        });
    }
}

