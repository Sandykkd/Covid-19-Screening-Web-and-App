package com.example.nav_end.ui.change_password;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.nav_end.LoginActivity;
import com.example.nav_end.MainActivity;
import com.example.nav_end.R;
import com.example.nav_end.SharedPrefManager;
import com.example.nav_end.User;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class GalleryFragment extends Fragment {
    Activity context;

    EditText psd;
    EditText newpass;
    EditText confirm;
    Button btn_change;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        View pass_view =  inflater.inflate(R.layout.fragment_gallery,container,false);
        psd = pass_view.findViewById(R.id.etOld);
        newpass = pass_view.findViewById(R.id.etNew);
        confirm = pass_view.findViewById(R.id.etConfirm);
        btn_change = pass_view.findViewById(R.id.buttonChange);

        btn_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PasswordChange();
            }
        });
        return pass_view;
    }


    private void PasswordChange(){
        final String cur_pass = psd.getText().toString();
        final String new_pass = newpass.getText().toString();
        final String conf_pass = confirm.getText().toString();

        if (TextUtils.isEmpty(cur_pass)) {
            psd.setError("Please enter your current password");
            psd.requestFocus();
            return;

        }


        if (TextUtils.isEmpty(new_pass)) {
            newpass.setError("Please enter your new password");
            newpass.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(conf_pass)) {
            confirm.setError("Enter your Password again");
            confirm.requestFocus();
            return;
        }

        if (!new_pass.equals(conf_pass)) {
            confirm.setError("Password mismatch");
            return;
        }

        final ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Updating....");
        progressDialog.show();


        StringRequest request = new StringRequest(Request.Method.POST, "http://192.168.43.123/sandy_temp/update.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //converting response to json object

                            JSONObject obj = new JSONObject(response);


                            //if no error in response
                            if (!obj.getBoolean("error")) {
                                Toast.makeText(getActivity().getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();

                                getActivity().finish();
                                //startActivity(new Intent(getActivity().getApplicationContext(), MainActivity.class));
                                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("temperaturesharedpref", Context.MODE_PRIVATE);

                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.clear();
                                editor.commit();
                                Intent logout = new Intent(getActivity(), LoginActivity.class);
                                startActivity(logout);
                            } else {

                                Toast.makeText(getActivity().getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                        progressDialog.dismiss();


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();

            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params = new HashMap<String,String>();

                params.put("id",SharedPrefManager.getInstance(getActivity()).getUser().getId());
                params.put("email",SharedPrefManager.getInstance(getActivity()).getUser().getEmail());
                params.put("password",cur_pass);
                params.put("newpassword",conf_pass);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(request);



    }
}