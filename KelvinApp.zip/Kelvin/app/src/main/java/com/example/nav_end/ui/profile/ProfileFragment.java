package com.example.nav_end.ui.profile;
import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;
import java.util.function.Function;
import java.util.stream.Collectors;

import androidx.annotation.RequiresApi;
import androidx.lifecycle.ViewModelProviders;

import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import android.content.Context;
import android.content.SharedPreferences;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.example.nav_end.LoginActivity;
import com.example.nav_end.MainActivity;
import com.example.nav_end.SharedPrefManager;

import android.widget.TextView;

import com.example.nav_end.R;
import com.example.nav_end.SharedPrefManager;

import static java.util.stream.Collectors.*;

public class ProfileFragment extends Fragment {

    TextView name;
    TextView email;
    TextView registerID;
    TextView dept;
    String text2Qr, text,textvalue,name1,id,dep;
    ImageView pic;

    SharedPreferences sharedPref;

    private ProfileViewModel mViewModel;

    public static ProfileFragment newInstance() {
        return new ProfileFragment();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View qrcode_view =inflater.inflate(R.layout.profile_fragment, container, false);
        TextView  email=qrcode_view.findViewById(R.id.email);
        TextView  name=qrcode_view.findViewById(R.id.name);
        TextView  registerID=qrcode_view.findViewById(R.id.registerID);
        TextView dept=qrcode_view.findViewById(R.id.dept);
        final ImageView pic=qrcode_view.findViewById(R.id.pic);

        String photoURL=SharedPrefManager.getInstance(getActivity()).getUser().getPhoto();


        String mainURL="http://192.168.43.123/sandy_temp/images/";

        String finalURL=mainURL+photoURL;




        //String server_url="http://192.168.43.135/sandy_temp/images/jrameee.jpg";
        ImageRequest imageRequest=new ImageRequest(finalURL, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap response) {
                pic.setImageBitmap(response);

            }
        }, 0, 0, ImageView.ScaleType.CENTER_CROP, null, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(ProfileFragment.this,"Something went wrong",Toast.LENGTH_LONG).show();

                error.printStackTrace();


            }
        });
        Singleton.getInstance(getContext()).addToRequestQueue(imageRequest);


        

        textvalue = SharedPrefManager.getInstance(getActivity()).getUser().getEmail();
        //Toast.makeText(getActivity(),"Passord " + SharedPrefManager.getInstance(getActivity()).getUser().getPassword(), Toast.LENGTH_SHORT).show();

        name1 =SharedPrefManager.getInstance(getActivity()).getUser().getName();
       // Toast.makeText(this.getActivity(),"Name "+name1 ,Toast.LENGTH_LONG).show();


        id =SharedPrefManager.getInstance(getActivity()).getUser().getId();
        dep=SharedPrefManager.getInstance(getActivity()).getUser().getDept();
        //Toast.makeText(this.getActivity()," "+nam ,Toast.LENGTH_LONG).show();
        text="ID";
        email.setText(textvalue);
        String name_f,dep_f;

        name_f=name1.toUpperCase();



        name.setText(name_f);
        registerID.setText(id);

        dep_f=dep.toUpperCase();
        dept.setText(dep_f);


        return qrcode_view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(ProfileViewModel.class);
        // TODO: Use the ViewModel
    }

}
